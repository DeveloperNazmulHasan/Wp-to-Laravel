<?php
/**
 * Plugin Name: WP-to-Laravel
 * Description: Send WooCommerce order data to Laravel API securely with WP Settings page and block repeated orders from same phone within a time interval (updates fields instead of creating a new one), keyed by your Custom Order Reference.
 * Version:     2.0
 * Author:      Nazmul Hoshen
* Text Domain: wp-to-laravel
 */

if ( ! defined( 'ABSPATH' ) ) exit;


function jxw_sanitize_base_url( $url ) {
    // basic URL sanitization
    $url = esc_url_raw( $url );

    // remove trailing slash
    $url = untrailingslashit( $url );

    // if they pasted the full endpoint, strip it off
    if ( preg_match( '#^(.*)/api/receive-wordpress-order$#i', $url, $m ) ) {
        $url = $m[1];
    }

    return $url;
}

/** 0) WooCommerce Active Check **/
add_action( 'plugins_loaded', 'jxw_check_woocommerce_active' );
function jxw_check_woocommerce_active() {
    if ( ! class_exists( 'WooCommerce' ) ) {
        add_action( 'admin_notices', function(){
            echo '<div class="notice notice-error"><p><strong>Jodex Connect WP</strong> requires <strong>WooCommerce</strong>.</p></div>';
        } );
    }
}

add_action( 'wp_enqueue_scripts', 'jxw_enqueue_custom_ref_js' );
function jxw_enqueue_custom_ref_js() {
    if ( ! is_checkout() ) {
        return;
    }
    wp_enqueue_script( 
        'jxw-custom-ref', 
        plugins_url( 'js/custom-ref.js', __FILE__ ), 
        [ 'jquery' ], 
        '1.0', 
        true 
    );
}

/** 1) Add & Save Custom Order Reference Field **/
function jxw_generate_unique_ref() {
    global $wpdb;

    do {
        $ref = 'CO-' . strtoupper( wp_generate_password( 8, false, false ) );
        $count = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->postmeta}
             WHERE meta_key = %s
               AND meta_value = %s",
            '_jxw_custom_order_id',
            $ref
        ) );
    } while ( $count > 0 );

    return $ref;
}

add_filter( 'woocommerce_checkout_get_value', 'jxw_regenerate_custom_order_id', 10, 2 );
function jxw_regenerate_custom_order_id( $value, $input_key ) {
    if ( 'custom_order_id' === $input_key ) {
        return jxw_generate_unique_ref();
    }
    return $value;
}

add_filter( 'woocommerce_checkout_fields', 'jxw_add_custom_order_id_field' );
function jxw_add_custom_order_id_field( $fields ) {
    $generated = jxw_generate_unique_ref();

    $fields['billing']['custom_order_id'] = [
        'type'              => 'hidden',
        'label'             => __( 'Custom Order Reference', 'jodex-connect-wp' ),
        'required'          => true,
        'default'           => $generated,
        'custom_attributes' => [ 'readonly' => 'readonly' ],
        'priority'          => 120,
    ];
    return $fields;
}

add_action( 'woocommerce_checkout_update_order_meta', 'jxw_save_custom_order_id_meta' );
function jxw_save_custom_order_id_meta( $order_id ) {
    if ( ! empty( $_POST['custom_order_id'] ) ) {
        $order = wc_get_order( $order_id );
        $order->update_meta_data(
            '_jxw_custom_order_id',
            sanitize_text_field( wp_unslash( $_POST['custom_order_id'] ) )
        );
        $order->save();
    }
}

/** 2) Enqueue Incomplete‑AJAX Script **/
add_action( 'wp_enqueue_scripts', 'jxw_incomplete_enqueue' );
function jxw_incomplete_enqueue(){
    if ( ! is_checkout() || ! get_option('jxw_enable_incomplete', 0 ) ) {
        return;
    }

    // collect cart items, shipping etc. (your existing code)
    $cart_items = [];
    foreach ( WC()->cart->get_cart() as $ci ) {
        $cart_items[] = [
            'sku'          => $ci['data']->get_sku(),
            'variation_id' => $ci['variation_id'] ?? null,
            'quantity'     => $ci['quantity'],
            'unit_price'   => (float)$ci['data']->get_price(),
            'discount'     => 0,
        ];
    }
    $shipping_lines = [];
    $packages = WC()->shipping()->get_packages();
    if ( ! empty($packages[0]['rates']) ) {
        foreach ( $packages[0]['rates'] as $rate ) {
            $shipping_lines[] = [
                'method_id' => $rate->get_method_id(),
                'total'     => (float)$rate->get_cost(),
            ];
        }
    }

    wp_enqueue_script(
        'jxw-incomplete',
        plugins_url( 'js/incomplete.js', __FILE__ ),
        [ 'jquery' ],
        '1.0',
        true
    );
    wp_localize_script( 'jxw-incomplete', 'jxw_incomplete_params', [
        'ajax_url'      => admin_url('admin-ajax.php'),
        // ALWAYS use get_option() + our fixed path
        'endpoint'      => esc_url_raw( get_option('jxw_api_endpoint') . '/api/receive-wordpress-order' ),
        'token'         => sanitize_text_field( get_option('jxw_api_token') ),
        'domain'        => preg_replace( '/^www\./i', '', parse_url( home_url(), PHP_URL_HOST ) ),
        'ip_address'    => WC_Geolocation::get_ip_address(),
        'line_items'    => $cart_items,
        'shipping_lines'=> $shipping_lines,
        'total'         => (float) WC()->cart->get_subtotal(),
        'shipping_cost' => (float) WC()->cart->get_shipping_total(),
    ] );
}

add_action('admin_enqueue_scripts', 'jxw_enqueue_admin_styles');
function jxw_enqueue_admin_styles( $hook_suffix ) {
    // শুধুমাত্র আমাদের Settings পেজে স্টাইল লোড হবে
    if ( $hook_suffix !== 'toplevel_page_jxw-connect-settings' ) {
        return;
    }

    wp_enqueue_style(
        'jxw-admin-css',                                           // হ্যান্ডল
        plugin_dir_url( __FILE__ ) . 'css/jxw-admin.css',          // ফাইল URL
        array(),                                                   // ডিপেন্ডেন্সি
        filemtime( plugin_dir_path( __FILE__ ) . 'css/jxw-admin.css' ) // ভের্শন
    );
} // <-- এই জায়গায় বন্ধ করতে হবে function

add_action('admin_menu','jxw_add_admin_menu');
function jxw_add_admin_menu(){
    add_menu_page('WP-to-Laravel Settings','WP-to-Laravel','manage_options','jxw-connect-settings','jxw_settings_page','dashicons-admin-generic',54);
}
// ১) Settings রেজিস্ট্রেশন আগের মতোই
// ১) Register Settings (add these two under your existing register_setting() calls)
add_action( 'admin_init', 'jxw_register_settings' );
function jxw_register_settings(){
    // API
    register_setting(
        'jxw_api_group',
        'jxw_api_endpoint',
        [
            'type'              => 'string',
            'sanitize_callback' => 'jxw_sanitize_base_url',
        ]
    );
    register_setting(
        'jxw_api_group',
        'jxw_api_token',
        [
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_text_field',
        ]
    );

    // General
    register_setting('jxw_general_group','jxw_block_ip_interval',['type'=>'integer','sanitize_callback'=>'absint']);
    register_setting('jxw_general_group','jxw_block_hotline',['type'=>'string','sanitize_callback'=>'sanitize_text_field']);
    
    register_setting('jxw_general_group','jxw_track_incomplete',['type'=>'integer','sanitize_callback'=>'absint','default'=>0]);
    register_setting('jxw_general_group','jxw_check_duplicate',['type'=>'integer','sanitize_callback'=>'absint','default'=>0]);
    register_setting('jxw_general_group','jxw_enable_incomplete',['type'=>'integer','sanitize_callback'=>'absint','default'=>0]);
}


// ৩) কার্ড-স্টাইল CSS
add_action('admin_head','jxw_admin_card_styles');
function jxw_admin_card_styles(){
    echo '<style>
      .jxw-row { display: flex; gap: 20px; margin-bottom: 20px; }
      .jxw-card { flex: 1; background: #fff; border: 1px solid #e1e1e1; border-radius: 4px; padding: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.05); }
      .jxw-card label { display: block; font-weight: bold; margin-bottom: 5px; }
      .jxw-card input[type="text"],
      .jxw-card input[type="url"],
      .jxw-card input[type="number"] { width: 100%; box-sizing: border-box; padding: 6px 8px; }
      .jxw-full { width: 100%; }
      .jxw-description { font-size: 12px; color: #666; margin-top: 4px; }
    </style>';
}

// ৪) Settings Page
function jxw_settings_page(){
    
    
    $tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : 'api';
    ?>
    <div class="wrap">
      <h1><?php esc_html_e('WP-to-Laravel Settings','jodex-connect-wp');?></h1>
      <h2 class="nav-tab-wrapper">
        <a href="<?php echo esc_url(admin_url('admin.php?page=jxw-connect-settings&tab=api')); ?>"
           class="nav-tab <?php echo $tab==='api'?'nav-tab-active':'';?>">
          <?php esc_html_e('API Connection','jodex-connect-wp');?>
        </a>
        <a href="<?php echo esc_url(admin_url('admin.php?page=jxw-connect-settings&tab=general')); ?>"
           class="nav-tab <?php echo $tab==='general'?'nav-tab-active':'';?>">
          <?php esc_html_e('Order Settings','jodex-connect-wp');?>
        </a>
      </h2>

      <form method="post" action="options.php">
        <?php if($tab==='api'): 
            settings_fields('jxw_api_group');
        ?>
          <div class="jxw-row">
            <div class="jxw-card">
              <label for="jxw_api_endpoint">
                <?php esc_html_e('Your Base URL','jodex-connect-wp');?>
              </label>
              <input type="url" id="jxw_api_endpoint" name="jxw_api_endpoint"
                     value="<?php echo esc_attr(get_option('jxw_api_endpoint'));?>" required>
            </div>
            <div class="jxw-card">
              <label for="jxw_api_token">
                <?php esc_html_e('API Token','jodex-connect-wp');?>
              </label>
              <input type="text" id="jxw_api_token" name="jxw_api_token"
                     value="<?php echo esc_attr(get_option('jxw_api_token'));?>" required>
            </div>
          </div>

        <?php else: 
            settings_fields('jxw_general_group');
        ?>
          <div class="jxw-row">
            <div class="jxw-card">
              <label for="jxw_block_ip_interval">
                <?php esc_html_e('Fake order Block Time','jodex-connect-wp');?>
              </label>
              <input type="number" id="jxw_block_ip_interval" name="jxw_block_ip_interval"
                     value="<?php echo esc_attr(get_option('jxw_block_ip_interval',10));?>" min="0">
              <p class="jxw-description">
                <?php esc_html_e('সেম আইপি থেকে কতক্ষনের মধ্যে ডাবল অর্ডার করতে পারবেনা','jodex-connect-wp');?>
              </p>
            </div>
            <div class="jxw-card">
              <label for="jxw_block_hotline">
                <?php esc_html_e('Block popup Hotline Number','jodex-connect-wp');?>
              </label>
              <input type="text" id="jxw_block_hotline" name="jxw_block_hotline"
                     value="<?php echo esc_attr(get_option('jxw_block_hotline','01740028481'));?>">
              <p class="jxw-description">
                <?php esc_html_e('ব্লক মডেলের ভিতরে যে Hotline  নাম্বার Show হবে সেটা','jodex-connect-wp');?>
              </p>
            </div>
          </div>
<div class="jxw-card ">
  <label for="jxw_enable_incomplete">
    <?php esc_html_e('Enable Incomplete Orders','jodex-connect-wp');?>
  </label>
  <label class="jxw-switch">
    <input
      type="checkbox"
      id="jxw_enable_incomplete"
      name="jxw_enable_incomplete"
      value="1"
      <?php checked( 1, get_option('jxw_enable_incomplete', 0) );?>
    >
    <span class="jxw-slider"></span>
  </label>
  <p class="jxw-description">
    <?php esc_html_e('আপনার সকল Incomplete অর্ডার দেখতে পারবেন WP-to-Laravel এর ড্যাশবোর্ডে ','jodex-connect-wp');?>
  </p>
</div>

        <?php endif; ?>

        <?php submit_button(); ?>
      </form>
    </div>
    <?php
}
/** 4) Block‑IP Script **/
add_action('wp_enqueue_scripts','jxw_block_ip_enqueue');
function jxw_block_ip_enqueue(){
    if(!is_checkout()) return;
    $ip        = WC_Geolocation::get_ip_address();
    $key       = 'jxw_last_order_'.md5($ip);
    $last_time = get_transient($key) ?: 0;

    wp_enqueue_script('jxw-block-ip',plugins_url('js/block-ip.js',__FILE__),['jquery'],'1.0',true);
    wp_localize_script('jxw-block-ip','jxw_block_params',[
        'interval'  => absint(get_option('jxw_block_ip_interval',0)),
        'hotline'   => esc_js(get_option('jxw_block_hotline','01740028481')),
        'last_time' => intval($last_time),
    ]);
    wp_enqueue_style('jxw-block-ip-css',plugins_url('css/block-ip.css',__FILE__));
}

/** 5) Incomplete Status **/
add_action('init','jxw_register_incomplete_status');
function jxw_register_incomplete_status(){
    register_post_status('wc-incomplete',[
        'label'                     => _x('Incomplete','Order status','jodex-connect-wp'),
        'public'                    => true,
        'show_in_admin_all_list'    => true,
        'show_in_admin_status_list' => true,
        'exclude_from_search'       => false,
        'label_count'               => _n_noop('Incomplete <span class="count">(%s)</span>','Incomplete <span class="count">(%s)</span>','jodex-connect-wp'),
    ]);
}
add_filter('wc_order_statuses','jxw_add_incomplete_to_statuses');
function jxw_add_incomplete_to_statuses($statuses){
    $new = [];
    foreach($statuses as $k=>$l){
        $new[$k] = $l;
        if($k === 'wc-pending'){
            $new['wc-incomplete'] = __('Incomplete','jodex-connect-wp');
        }
    }
    return $new;
}

/** 6) AJAX Handler **/
/**
 * AJAX Handler: interval‑aware create/update of incomplete orders.
 */
/**
 * AJAX Handler: interval‑aware create/update of incomplete orders,
 * but without saving any “Incomplete” in WP—শুধু API-তে পাঠাবে।
 */
add_action( 'wp_ajax_nopriv_jxw_incomplete_order', 'jxw_ajax_incomplete_order' );
add_action( 'wp_ajax_jxw_incomplete_order',        'jxw_ajax_incomplete_order' );
// Replace your existing jxw_ajax_incomplete_order() with this version
function jxw_ajax_incomplete_order() {
    if ( ! get_option( 'jxw_enable_incomplete', 0 ) ) {
        wp_send_json_error( 'disabled' );
    }

    $custom = sanitize_text_field( $_POST['custom_order_id'] ?? '' );
    if ( '' === $custom ) {
        wp_send_json_error( 'missing-custom-id' );
    }

    $rawPhone = $_POST['phone'] ?? '';
    $phone = preg_replace('/\D/', '', $rawPhone);

    $first_name = sanitize_text_field( $_POST['first_name'] ?? '' );
    $address_1  = sanitize_text_field( $_POST['address_1'] ?? '' );

    $phoneOk = strlen( $phone ) === 11;
    $nameOk  = mb_strlen(trim($first_name)) >= 3;
    $addrOk  = mb_strlen(trim($address_1)) >= 15;

    // address send requires phone == 11
    $addrTrigger = $addrOk && $phoneOk;

    $promote = ! empty( $_POST['promote'] );

    // Allowed triggers for sending incomplete:
    //  - phoneOk OR nameOk OR (addrOk AND phoneOk)
    if ( ! $promote && ! ( $phoneOk || $nameOk || $addrTrigger ) ) {
        wp_send_json_success( [ 'skipped' => true, 'reason' => 'criteria-not-met' ] );
    }

    // Rate-limit by phone (or IP+domain)
    $rateKey = 'jxw_incomplete_rl_' . ( $phoneOk ? md5($phone) : md5( WC_Geolocation::get_ip_address() . '|' . ($_POST['domain'] ?? '') ) );
    $rateWindow = 10; // seconds

    if ( ! $promote && get_transient( $rateKey ) ) {
        wp_send_json_success( [ 'skipped' => true, 'reason' => 'throttled' ] );
    }
    set_transient( $rateKey, time(), $rateWindow );

    // Build minimal payload
    $payload = [
        'id' => $custom,
        'billing' => [
            'phone' => $phone,
            'first_name' => $first_name,
            'address_1' => $address_1,
            'email' => sanitize_email( $_POST['email'] ?? '' ),
        ],
        'total' => floatval( $_POST['total'] ?? 0 ),
        'shipping_cost' => floatval( $_POST['shipping_cost'] ?? 0 ),
        'shipping_lines' => $_POST['shipping_lines'] ?? [],
        'line_items' => $_POST['line_items'] ?? [],
        'domain' => sanitize_text_field( $_POST['domain'] ?? '' ),
        'ip_address' => sanitize_text_field( $_POST['ip_address'] ?? '' ),
    ];

    // If not promote: send Incomplete to API and DO NOT create/update WP orders
    if ( ! $promote ) {
        $payload['status'] = 'Incomplete';

        $endpoint = esc_url_raw( $_POST['endpoint'] ?? get_option('jxw_api_endpoint') . '/api/receive-wordpress-order' );
        $token = sanitize_text_field( $_POST['token'] ?? get_option('jxw_api_token') );

        $resp = wp_remote_post(
            $endpoint,
            [
                'headers' => [
                    'Content-Type' => 'application/json',
                    'Authorization' => 'Bearer ' . $token,
                ],
                'body' => wp_json_encode( $payload ),
                'timeout' => 8,
            ]
        );

        if ( is_wp_error( $resp ) ) {
            wp_send_json_error( $resp->get_error_message() );
        }

        // IMPORTANT: Do NOT create or update WP orders here (keeps WP dashboard clean)
        wp_send_json_success( [ 'order_id' => $custom, 'saved' => true ] );
    }

    // If promote provided via AJAX (unlikely in new flow) — just forward Final to API and do NOT create WP order.
    $payload['status'] = 'Final';
    $endpoint = esc_url_raw( $_POST['endpoint'] ?? get_option('jxw_api_endpoint') . '/api/receive-wordpress-order' );
    $token = sanitize_text_field( $_POST['token'] ?? get_option('jxw_api_token') );

    $resp = wp_remote_post(
        $endpoint,
        [
            'headers' => [
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . $token,
            ],
            'body' => wp_json_encode( $payload ),
            'timeout' => 15,
        ]
    );

    if ( is_wp_error( $resp ) ) {
        wp_send_json_error( $resp->get_error_message() );
    }

    wp_send_json_success( [ 'order_id' => $custom, 'promoted' => true ] );
}





function jxw_send_order_to_api( $order, $status = 'Final' ) {
    if ( ! $order || ! is_object($order) ) return false;

    // prevent duplicate final sends
    if ( $status === 'Final' ) {
        if ( $order->get_meta('_jxw_final_sent') ) {
            return false; // already sent
        }
    }

    $custom_id = $order->get_meta( '_jxw_custom_order_id' ) ?: ('CO-WP-' . $order->get_id());

    $billing = [
        'phone' => $order->get_billing_phone(),
        'first_name' => $order->get_billing_first_name(),
        'last_name'  => $order->get_billing_last_name(),
        'address_1'  => $order->get_billing_address_1(),
        'email'      => $order->get_billing_email(),
    ];

    // line items
    $line_items = [];
    foreach ( $order->get_items() as $item_id => $item ) {
        $product = $item->get_product();
        $sku = $product ? $product->get_sku() : '';
        $variation_id = $item->get_variation_id() ?: null;
        $line_items[] = [
            'sku' => $sku,
            'variation_id' => $variation_id,
            'quantity' => intval( $item->get_quantity() ),
            'unit_price' => floatval( $item->get_total() / max(1, $item->get_quantity()) ),
            'discount' => 0,
        ];
    }

    $payload = [
        'id' => (string) $custom_id,
        'billing' => $billing,
        'total' => floatval( $order->get_total() ),
        'shipping_cost' => floatval( $order->get_shipping_total() ),
        'shipping_lines' => [], // optional: you can fill method ids if needed
        'line_items' => $line_items,
        'domain' => preg_replace('/^www\./i','', parse_url( home_url(), PHP_URL_HOST )),
        'ip_address' => method_exists($order,'get_customer_ip_address') ? $order->get_customer_ip_address() : WC_Geolocation::get_ip_address(),
        'status' => $status,
    ];

    $endpoint = esc_url_raw( get_option('jxw_api_endpoint') . '/api/receive-wordpress-order' );
    $token = sanitize_text_field( get_option('jxw_api_token') );

    $resp = wp_remote_post(
        $endpoint,
        [
            'headers' => [
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . $token,
            ],
            'body' => wp_json_encode( $payload ),
            'timeout' => 15,
        ]
    );

    if ( is_wp_error( $resp ) ) {
        error_log('jxw: send_order_to_api error: ' . $resp->get_error_message());
        return false;
    }

    // mark final sent to avoid duplicates
    if ( $status === 'Final' ) {
        $order->update_meta_data('_jxw_final_sent', time());
        $order->save();
    }

    return true;
}





/** 7) Promote on Woo Hooks **/
add_action('woocommerce_payment_complete','jxw_promote_incomplete_order',10,1);
add_action('woocommerce_thankyou','jxw_promote_incomplete_order',10,1);
function jxw_promote_incomplete_order($order_id){
    if ( ! $order_id ) return;

    $order = wc_get_order($order_id);
    if ( ! $order ) return;

    // If final already sent, skip
    if ( $order->get_meta('_jxw_final_sent') ) {
        return;
    }

    // send final to API (this will set _jxw_final_sent meta)
    jxw_send_order_to_api( $order, 'Final' );
}


/** 8) Save last order time by IP **/
add_action('woocommerce_thankyou','jxw_save_last_order_time',20);
add_action('woocommerce_order_status_completed','jxw_save_last_order_time',20);
function jxw_save_last_order_time($order_id){
    $o        = wc_get_order($order_id);
    $ip       = method_exists($o,'get_customer_ip_address') 
                  ? $o->get_customer_ip_address() 
                  : WC_Geolocation::get_ip_address();
    $interval = absint(get_option('jxw_block_ip_interval',0));
    if($interval>0){
        set_transient('jxw_last_order_'.md5($ip), time(), $interval * 60);
    }
}