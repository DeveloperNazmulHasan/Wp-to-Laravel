(function($){
  'use strict';

  // thresholds
  var PHONE_LEN = 11;
  var NAME_MIN  = 3;
  var ADDR_MIN  = 15;

  // debounce delays (ms)
  var INPUT_DEBOUNCE = 300;

  // timers / last-sent trackers
  var timers = { phone: null, name: null, addr: null };
  var lastSent = { phone: null, name: null, addr: null };

  // helpers
  function makeRef(){
    var chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    var id = '';
    for ( var i = 0; i < 8; i++ ) {
      id += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return 'CO-' + id;
  }

  function getCookie(name){
    var m = document.cookie.match(new RegExp('(^| )'+name+'=([^;]+)'));
    return m ? m[2] : null;
  }

  function setCookie(name, value){
    // set as session cookie (no expires) but we will override it on every load intentionally
    document.cookie = name + '=' + value + '; path=/';
  }

  function clearFieldsExceptRef(){
    // Clear visible text/email/tel/textarea fields on page load to avoid old typed values/autofill
    // Keep the custom_order_id hidden field intact (we'll write new ref into it)
    $('form.checkout')
      .find('input[type="text"], input[type="email"], input[type="tel"], textarea')
      .each(function(){
        // if this is the custom id field, skip it
        var id = this.id || '';
        var name = this.name || '';
        if ( id === 'custom_order_id' || id === 'jxw_incomplete_id' || name === 'custom_order_id' ) {
          return;
        }
        try {
          this.value = '';
          this.defaultValue = '';
        } catch (e) {}
        // discourage browser autofill
        $(this).attr('autocomplete','off');
      });

    // Also hint for inputs to avoid browser autofill (some browsers ignore)
    $('form.checkout').attr('autocomplete','off');
  }

  function cleanPhone(raw){
    var d = (raw || '').replace(/\D/g, '');
    return (d.length > PHONE_LEN) ? d.slice(-PHONE_LEN) : d;
  }

  function populateRef(code){
    // Always overwrite cookie and hidden input with new code (this ensures per-page-load new id)
    setCookie('jxw_incomplete_id', code);

    if ($('#custom_order_id').length) {
      $('#custom_order_id').val(code);
      $('#custom_order_id').attr('value', code);
    }
    if ($('#jxw_incomplete_id').length){
      $('#jxw_incomplete_id').val(code);
    } else {
      // ensure hidden input exists
      $('<input>')
        .attr({ type: 'hidden', name: 'custom_order_id', id: 'jxw_incomplete_id', value: code })
        .appendTo('form.checkout');
    }
  }

  // thresholds checkers
  function phoneThresholdMet(phoneClean){ return phoneClean.length === PHONE_LEN; }
  function nameThresholdMet(first){ return first && first.trim().length >= NAME_MIN; }
  function addrThresholdMet(addr){ return addr && addr.trim().length >= ADDR_MIN; }

  // sendIncomplete (no 'promote' here; final is sent server-side)
  function sendIncomplete(){
    var phone = cleanPhone($('#billing_phone').val() || '');
    var data = {
      action: 'jxw_incomplete_order',
      custom_order_id: getCookie('jxw_incomplete_id'),
      phone: phone,
      first_name: $('#billing_first_name').val(),
      address_1: $('#billing_address_1').val(),
      email: $('#billing_email').val(),
      endpoint: jxw_incomplete_params.endpoint,
      token: jxw_incomplete_params.token,
      domain: jxw_incomplete_params.domain,
      ip_address: jxw_incomplete_params.ip_address,
      total: jxw_incomplete_params.total,
      shipping_cost: jxw_incomplete_params.shipping_cost,
      shipping_lines: jxw_incomplete_params.shipping_lines,
      line_items: jxw_incomplete_params.line_items
    };

    return $.post(jxw_incomplete_params.ajax_url, data, null, 'json')
      .done(function(res){
        if (res && res.success && res.data && res.data.order_id){
          setCookie('jxw_incomplete_id', res.data.order_id);
          if ($('#jxw_incomplete_id').length) {
            $('#jxw_incomplete_id').val(res.data.order_id);
          }
        }
      }).fail(function(err){
        console.warn('[jxw] sendIncomplete failed', err);
      });
  }

  // input handlers (debounced)
  function handlePhoneInput(){
    if (timers.phone) clearTimeout(timers.phone);
    timers.phone = setTimeout(function(){
      var phoneClean = cleanPhone($('#billing_phone').val() || '');
      if ( phoneThresholdMet(phoneClean) && lastSent.phone !== phoneClean ) {
        lastSent.phone = phoneClean;
        var addr = ($('#billing_address_1').val() || '').trim();
        if ( addrThresholdMet(addr) ) lastSent.addr = addr.slice(0, ADDR_MIN);
        sendIncomplete().done(function(){ console.log('[jxw] sent on phone reached 11'); });
      } else {
        if (!phoneThresholdMet(phoneClean)) lastSent.phone = null;
      }
    }, INPUT_DEBOUNCE);
  }

  function handleNameInput(){
    if (timers.name) clearTimeout(timers.name);
    timers.name = setTimeout(function(){
      var first = ($('#billing_first_name').val() || '').trim();
      if ( nameThresholdMet(first) && lastSent.name !== first ) {
        lastSent.name = first;
        sendIncomplete().done(function(){ console.log('[jxw] sent on name >=3'); });
      } else {
        if (!nameThresholdMet(first)) lastSent.name = null;
      }
    }, INPUT_DEBOUNCE);
  }

  function handleAddrInput(){
    if (timers.addr) clearTimeout(timers.addr);
    timers.addr = setTimeout(function(){
      var phoneClean = cleanPhone($('#billing_phone').val() || '');
      var addr = ($('#billing_address_1').val() || '').trim();

      // address send requires phone==11
      if ( phoneThresholdMet(phoneClean) && addrThresholdMet(addr) ) {
        var marker = addr.slice(0, ADDR_MIN);
        if ( lastSent.addr !== marker ) {
          if ( lastSent.phone !== phoneClean ) lastSent.phone = phoneClean;
          lastSent.addr = marker;
          sendIncomplete().done(function(){ console.log('[jxw] sent on addr >=15 with phone 11'); });
        }
      } else {
        if (!addrThresholdMet(addr)) lastSent.addr = null;
      }
    }, INPUT_DEBOUNCE);
  }

  // init: ALWAYS generate a NEW ref on page load and clear fields (prevent reuse of old cookie/value)
  function initFull(){
    // clear user-visible fields (avoid previous typed values/autofill)
    clearFieldsExceptRef();

    // generate a fresh code on every page load and overwrite cookie/hidden input
    var code = makeRef();
    populateRef(code);

    // if fields already meet thresholds (unlikely immediately after clearing), we still check
    var phoneClean = cleanPhone($('#billing_phone').val() || '');
    var first = ($('#billing_first_name').val() || '').trim();
    var addr = ($('#billing_address_1').val() || '').trim();

    if ( phoneThresholdMet(phoneClean) && lastSent.phone !== phoneClean ) {
      lastSent.phone = phoneClean;
      sendIncomplete().done(function(){ console.log('[jxw] init send: phone'); });
      if ( addrThresholdMet(addr) ) lastSent.addr = addr.slice(0, ADDR_MIN);
    }
    if ( nameThresholdMet(first) && lastSent.name !== first ) {
      lastSent.name = first;
      sendIncomplete().done(function(){ console.log('[jxw] init send: name'); });
    }
    if ( phoneThresholdMet(phoneClean) && addrThresholdMet(addr) ) {
      var marker = addr.slice(0, ADDR_MIN);
      if ( lastSent.addr !== marker ) {
        lastSent.addr = marker;
        sendIncomplete().done(function(){ console.log('[jxw] init send: addr'); });
      }
    }
  }

  // bind events
  $(document).ready(function(){
    initFull();
    $('#billing_phone').on('input', handlePhoneInput);
    $('#billing_first_name').on('input', handleNameInput);
    $('#billing_address_1').on('input', handleAddrInput);

    $(window).on('load', initFull);
    window.addEventListener('pageshow', function(evt){ initFull(); });
  });

  // final submit handler: DO NOT send final via AJAX here.
  // Let WooCommerce create the WP order, and plugin's thankyou hook will send Final to API.
  var form = $('form.checkout');
  form.off('submit.jxw'); // remove old handler if present

})(jQuery);