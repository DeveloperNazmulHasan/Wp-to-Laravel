jQuery(function($){
  // ক্লায়েন্ট-সাইড ব্লক চেক
  console.log('block-ip.js loaded', wtl_block_params);
  $(document).on('click.blockIp', '#place_order', function(e){
    var interval = wtl_block_params.interval,
        lastTime = wtl_block_params.last_time,
        now = Math.floor(Date.now()/1000),
        elapsed = now - lastTime;

    if ( interval > 0 && lastTime > 0 && elapsed < interval * 60 ) {
      e.preventDefault(); e.stopPropagation();
      var rem = Math.ceil((interval*60 - elapsed) / 60);
      showJxwModal(rem);
    }
    // যদি ব্লক না থাকে, সাবমিশন চলতে দাও (WordPress/WOOCS নিজেই হ্যান্ডেল করবে)
  });

  function showJxwModal(remaining) {
    if ($('#jxw-block-modal').length) return;
    var hotline = wtl_block_params.hotline;
    var html = '\
      <div id="jxw-block-modal" class="jxw-modal-overlay">\
        <div class="jxw-modal">\
          <span class="jxw-modal-close">&times;</span>\
          <div class="jxw-modal-icon">&#10006;</div>\
          <h2>Maybe Fake Order</h2>\
          <p>আপনি আবার '+remaining+' মিনিট পর অর্ডার করতে পারবেন<br>প্রয়োজনে কল করুন:</p>\
          <p class="jxw-modal-hotline">'+hotline+'</p>\
          <button class="jxw-modal-call">CALL NOW</button>\
        </div>\
      </div>';
    $('body').append(html);
  }

  $('body').on('click', '.jxw-modal-close', function(){
    $('#jxw-block-modal').remove();
  }).on('click', '.jxw-modal-call', function(){
    window.location.href = 'tel:' + wtl_block_params.hotline;
  });
});